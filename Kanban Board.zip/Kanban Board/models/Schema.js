const mongoose=require("mongoose");

const todoSchema=new mongoose.Schema({
    id:{
        type:Number,
        unique:true
    },
    stage:{
        type:Number,
        
    },
    title:{
        type:String,
    }
})


module.exports=mongoose.model('todolist',todoSchema);
