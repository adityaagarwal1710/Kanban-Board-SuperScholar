const express=require("express")
const app=express();
const TASK=require('./models/Schema.js')
var bodyParser = require("body-parser");
const mongoose=require("mongoose")





mongoose.connect('mongodb://localhost:27017/TODODemo', { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log("MONGO CONNECTION OPEN!!!")
    })
    .catch(err => {
        console.log("OH NO MONGO CONNECTION ERROR!!!!")
        console.log(err)
    })
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({extended: true}));
app.use(express.urlencoded({ extended: true }));


//localhost:3000/boards     (POST REQUEST with title)

app.post('/boards',async(req,res)=>{
    const t=req.body.title;
   
    const task_id= await TASK.find().sort({"id":-1}).limit(1)
    var max_id=parseInt(task_id[0].id)
    // console.log((task_id[0].id))
 
    const new_task=new TASK({id:max_id+1,stage:1,title:t})
    await new_task.save().then(()=>{console.log("task Saved")}).
    catch((err)=>{console.log(err.message);});
    return res.status(201).json(new_task);
})



// localhost:3000/boards/:id    (PUT Request)

app.put('/boards/:id',async(req,res)=>{
    const stage_value=parseInt(req.body.stage);
    const id_value=req.params.id;

    if(stage_value>3)return res.status(400).json("");
    else{
        try{
    
            const find_task=await TASK.findOne({id:req.params.id})
            const task_id=(find_task._id.valueOf());
            const find_id=await TASK.findByIdAndUpdate({_id:task_id},{stage:stage_value})
             if(!find_id){
                 return res.status(400).json({success:false, message:"Can not find this id"});
                }
            else{
                const new_value=await TASK.findOne({id:req.params.id});
                return res.status(200).json({success:true,data:new_value})
                }
    }
    catch(err){
    res.status(400).send({success:false})
    console.log(err.message)
    }
    
    }
})


app.listen(3000,()=>{
    console.log("Server Running on PORT 3000");
})